function buildPattern(character, maxCount, rounds) {
  if (typeof character !== "string" || character.length === 0) {
    throw new Error("character must be a non-empty string");
  }

  if (!Number.isInteger(maxCount) || maxCount < 1) {
    throw new Error("maxCount must be a positive integer");
  }

  if (!Number.isInteger(rounds) || rounds < 1) {
    throw new Error("rounds must be a positive integer");
  }

  const lines = [];

  for (let round = 0; round < rounds; round += 1) {
    for (let count = 1; count <= maxCount; count += 1) {
      lines.push(character.repeat(count));
    }

    for (let count = maxCount - 1; count >= 1; count -= 1) {
      lines.push(character.repeat(count));
    }
  }

  return lines;
}

const [character = "1", maxCountArg = "4", roundsArg = "3"] = process.argv.slice(2);
const output = buildPattern(character, Number(maxCountArg), Number(roundsArg));

console.log(output.join("\n"));

module.exports = { buildPattern };
